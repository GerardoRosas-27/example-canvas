

<jsxgraph width="500" height="500" box="box">
 var board = JXG.JSXGraph.initBoard('box', {axis:true, boundingbox: [-3, 8, 50, -8]});
 var series = board.create('curve', [[], []], {strokeColor: 'black'});
 var n;
 
 var series_add = function() {
    var val = a_n(n);
    if (series.dataY.length > 0) {
      val += series.dataY[series.dataY.length - 1];
    }
    series.dataX.push(n);
    series.dataY.push(val);
    n++;
 };

 var txt2 = board.create('text', [15, 1.8, function() { return 'n=' + (series.dataX.length-1) + ': value = ' + series.dataY[series.dataY.length - 1]; }], {strokeColor: 'black'});

var TO;

var approx = function() {
     series_add();
     board.update();
     if (series.dataX.length <= 50) {
         TO = setTimeout(approx, 500);
     }
};

var a_n;
var start_approx = function() {
  series.dataX = [];
  series.dataY = [];

  var txtraw = document.getElementById('input').value;
  a_n = board.jc.snippet(txtraw, true, 'n', true);
  n = parseInt(document.getElementById('startval').value);
  approx();
}

var clear_all = function() {
  clearTimeout(TO);
};

</jsxgraph>

===The underlying JavaScript code===
<source lang="javascript">
 var board = JXG.JSXGraph.initBoard('box', {axis:true, boundingbox: [-3, 8, 50, -8]});
 var series = board.create('curve', [[], []], {strokeColor: 'black'});
 var n;
 
 var series_add = function() {
    var val = a_n(n);
    if (series.dataY.length > 0) {
      val += series.dataY[series.dataY.length - 1];
    }
    series.dataX.push(n);
    series.dataY.push(val);
    n++;
 };

 var txt2 = board.create('text', [15, 1.8, function() { return 'n=' + (series.dataX.length-1) + ': value = ' + series.dataY[series.dataY.length - 1]; }], {strokeColor: 'black'});

var TO;

var approx = function() {
     series_add();
     board.update();
     if (series.dataX.length <= 50) {
         TO = setTimeout(approx, 500);
     }
};

var a_n;
var start_approx = function() {
  series.dataX = [];
  series.dataY = [];

  var txtraw = document.getElementById('input').value;
  a_n = board.jc.snippet(txtraw, true, 'n', true);
  n = parseInt(document.getElementById('startval').value);
  approx();
}

var clear_all = function() {
  clearTimeout(TO);
};

</source>